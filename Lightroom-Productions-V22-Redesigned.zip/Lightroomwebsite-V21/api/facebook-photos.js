// Wedding Capital Facebook photo feed for Lightroom Productions.
// Keep FACEBOOK_PAGE_ACCESS_TOKEN server-side in Vercel environment variables.
const GRAPH_VERSION = process.env.FACEBOOK_GRAPH_VERSION || 'v26.0';
const PAGE_USERNAME = process.env.FACEBOOK_PAGE_USERNAME || 'weddingcapital';

async function handler(req, res) {
  try {
    if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
    const token = process.env.FACEBOOK_PAGE_ACCESS_TOKEN;
    if (!token) {
      return res.status(503).json({
        error: 'Facebook integration is not configured',
        message: 'Add FACEBOOK_PAGE_ACCESS_TOKEN in Vercel Environment Variables.'
      });
    }

    const requested = Math.min(Math.max(Number(req.query?.limit || 60), 1), 100);
    const maxPages = Math.min(Math.max(Number(req.query?.pages || 3), 1), 10);

    const pageUrl = new URL(`https://graph.facebook.com/${GRAPH_VERSION}/${encodeURIComponent(PAGE_USERNAME)}`);
    pageUrl.searchParams.set('fields', 'id,name');
    pageUrl.searchParams.set('access_token', token);
    const pageResponse = await fetch(pageUrl);
    const pageData = await pageResponse.json();
    if (!pageResponse.ok || pageData.error) {
      return res.status(502).json({ error: 'Facebook page lookup failed', details: pageData.error || pageData });
    }

    let next = new URL(`https://graph.facebook.com/${GRAPH_VERSION}/${pageData.id}/photos`);
    next.searchParams.set('type', 'uploaded');
    next.searchParams.set('fields', 'id,name,link,images,created_time');
    next.searchParams.set('limit', String(requested));
    next.searchParams.set('access_token', token);

    const photos = [];
    for (let page = 0; page < maxPages && next && photos.length < 1000; page += 1) {
      const response = await fetch(next);
      const data = await response.json();
      if (!response.ok || data.error) {
        return res.status(502).json({ error: 'Facebook photo feed failed', details: data.error || data });
      }
      for (const item of data.data || []) {
        const image = Array.isArray(item.images) && item.images.length ? item.images[0].source : null;
        if (image) photos.push({
          id: item.id,
          title: item.name || 'Wedding Capital',
          image,
          link: item.link || `https://www.facebook.com/${item.id}`,
          created_time: item.created_time || null
        });
      }
      const pagingNext = data.paging?.next;
      next = pagingNext ? new URL(pagingNext) : null;
    }

    res.setHeader('Cache-Control', 's-maxage=1800, stale-while-revalidate=86400');
    return res.status(200).json({
      page: { id: pageData.id, name: pageData.name, url: 'https://www.facebook.com/weddingcapital' },
      count: photos.length,
      photos
    });
  } catch (error) {
    return res.status(500).json({ error: 'Unexpected Facebook integration error' });
  }
}

module.exports = handler;
